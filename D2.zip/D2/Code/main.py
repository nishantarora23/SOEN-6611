import tkinter as tk
from gui import MetricsApp

if __name__ == "__main__":
    root = tk.Tk()
    app = MetricsApp(root)
    root.mainloop()
